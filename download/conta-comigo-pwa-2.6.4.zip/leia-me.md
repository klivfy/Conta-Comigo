# Conta Comigo 2.6.4 — PWA

Versão web instalável e offline do jogo, para navegadores de **computador** e para o
**iPhone/iPad** (Safari: Compartilhar, Adicionar à Tela de Início).

## E no Android?
O Android **não usa a PWA**. Lá o Conta Comigo é um app local da Google Play: o jogo vai
**dentro do pacote**, abre sem internet desde o primeiro toque e não depende deste site.
Em navegador Android esta página não oferece instalação e não guarda cache offline.

## Como hospedar
1. Publique esta pasta em um endereço **https** (GitHub Pages, Netlify, servidor da escola…).
2. Abra o endereço no navegador e use **Instalar** (Chrome/Edge) ou **Adicionar à Tela de Início** (Safari).
3. O service worker `sw.js` guarda o app no cache e ele passa a funcionar offline.

## Privacidade
Tudo roda **local no dispositivo** (sem servidores, sem contas, sem anúncios).
O progresso fica no armazenamento do navegador; "Limpar dados do site" apaga —
use o backup nas opções do painel dos responsáveis.

## Conteúdo desta pasta
- `index.html` — o jogo (o mesmo motor das builds de extensão)
- `manifest.webmanifest` — identidade do app instalável
- `sw.js` — cache offline
- `icons/` — ícones 192/512 e maskable
- `css/`, `js/` — estilos e motor compartilhados
