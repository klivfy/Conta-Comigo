'use strict';
/* ==================== Conta Comigo v2.1 — nova aba (S33) ==================== */
let NTQ = null;

function ntRenderStats() {
  const p = P();
  $('#nt-stars').textContent = String(p.stars);
  $('#nt-streak').textContent = String(p.streak || 0);
  const st = p.stars >= 100 ? { e: '🦊', k: 'st_big' } : p.stars >= 30 ? { e: '🐣', k: 'st_baby' } : { e: '🥚', k: 'st_egg' };
  $('#nt-mascot').textContent = st.e + (p.hat || '');
  $('#nt-stage').textContent = t(st.k);
}

function ntQuestion() {
  const p = P();
  const mode = pick(['contar', 'somar', 'subtrair']);
  const lv = clamp(activeLevel(mode), 1, 2);
  NTQ = GENS[mode](lv);
  $('#nt-q').textContent = NTQ.display;
  $('#nt-done').classList.add('hidden');
  $('#nt-play').classList.remove('hidden');
  const box = $('#nt-ans');
  box.innerHTML = '';
  shuffle(NTQ.options).forEach((o) => {
    const b = document.createElement('button');
    b.textContent = String(o);
    b.addEventListener('click', () => {
      if (Number(b.textContent) === NTQ.answer) {
        b.classList.add('good');
        p.stars += 1; saveState();
        ntRenderStats();
        $('#nt-play').classList.add('hidden');
        const d = $('#nt-done');
        d.textContent = '🎉 +1 ⭐ ' + pick(I18N[LANG].praise);
        d.classList.remove('hidden');
        // a nova aba não carrega ui.js: sem a guarda, o erro parava a rodada e a ofensiva nunca contava
        if (typeof confetti === 'function') confetti(18);
        if (p.lastPlay !== fmtDate()) {
          p.streak = nextStreak(p, new Date());
          p.lastPlay = fmtDate(); saveState();
        }
        setTimeout(ntQuestion, 1800);
      } else {
        b.disabled = true; b.style.opacity = '.4';
        SFX.wrong();
      }
    });
    box.appendChild(b);
  });
}

function ntShowGame() {
  $('#nt-title').textContent = t('appName');
  $('#nt-sub').textContent = t('subtitle');
  ntRenderStats();
  ntQuestion();
}
function ntShowOff() {
  $('#nt-play').classList.add('hidden');
  $('#nt-done').classList.add('hidden');
  $('#nt-sub').textContent = t('off');
  $('#nt-note').textContent = t('s_newtab_note');
  ntPaintToggle();
}
/* botão liga/desliga com nome e estado para leitor de tela (antes era só o glifo ⏻) */
function ntPaintToggle() {
  const on = !!G().newtabOn, b = $('#nt-toggle');
  b.textContent = '⏻';
  b.setAttribute('aria-pressed', String(on));
  b.setAttribute('aria-label', t(on ? 'nt_turn_off' : 'nt_turn_on'));
  b.title = b.getAttribute('aria-label');
}
async function bootNewtab() {
  await initDB();
  applyLang();
  applyTheme(G()); // a nova aba também segue o tema do jogo (e o modo escuro no 'auto')
  ntPaintToggle();
  if (G().newtabOn) ntShowGame(); else ntShowOff();
  $('#nt-open').addEventListener('click', () => {
    const url = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) ? chrome.runtime.getURL('game.html') : 'game.html';
    // v2.1: na extensão, abre janela nativa em tela cheia (mesmo caminho do ícone)
    try {
      if (typeof chrome !== 'undefined' && chrome.windows && chrome.windows.create) {
        chrome.windows.create({ url, type: 'popup', focused: true, state: 'fullscreen' }, () => { void chrome.runtime.lastError; });
        return;
      }
    } catch (e) { /* cai para navegação */ }
    location.href = url;
  });
  $('#nt-toggle').addEventListener('click', () => {
    G().newtabOn = !G().newtabOn;
    saveState(true);
    ntPaintToggle();
    if (G().newtabOn) { $('#nt-note').textContent = ''; ntShowGame(); } else ntShowOff();
  });
}
window.CC = {};
bootNewtab();
