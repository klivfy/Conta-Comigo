'use strict';
/* Conta Comigo PWA — service worker (offline-first do app shell) */
const CACHE = 'conta-comigo-2.8.0-b3bc28c889';
const ASSETS = ["./index.html", "./options.html", "./manifest.webmanifest", "./css/style.css", "./css/fonts/nunito-latin.woff2", "./js/boot.js", "./js/engine.js", "./js/ui.js", "./js/i18n.js", "./js/options.js", "./icons/icon-192.png", "./icons/icon-512.png", "./icons/icon-maskable-192.png", "./icons/icon-maskable-512.png"];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request).then((hit) => hit ||
      fetch(e.request).then((res) => {
        // só guarda respostas válidas do próprio site (404/erros não ficam presos no cache)
        if (res.ok && res.type === 'basic') {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy)).catch(() => {});
        }
        return res;
      }).catch(() => (e.request.mode === 'navigate' ? caches.match('./index.html') : Response.error()))
    )
  );
});
