# Conta Comigo 2.8.0 — PWA

Versão web instalável e offline do jogo, para navegadores de **computador**, para o
**Android** (Chrome: botão Instalar na tela inicial) e para o **iPhone/iPad** (Safari: Compartilhar,
Adicionar à Tela de Início; o jogo mostra o passo a passo).

## PWA ou app?
No Android e no iPhone existe também o app local (Google Play e App Store): o jogo vai **dentro do
pacote**, a voz e o progresso são do sistema e nada depende deste site. A PWA é o caminho sem loja:
instala por um endereço https, atualiza ao reabrir e guarda o progresso no armazenamento do navegador
(faça o backup nas opções do painel dos responsáveis).

## Como hospedar
1. Publique esta pasta em um endereço **https** (GitHub Pages, Netlify, servidor da escola…).
2. Abra o endereço no navegador e use **Instalar** (Chrome/Edge) ou **Adicionar à Tela de Início** (Safari).
3. O service worker `sw.js` guarda o app no cache e ele passa a funcionar offline.

## Privacidade
Tudo roda **local no dispositivo** (sem servidores, sem contas, sem anúncios).
O progresso fica no armazenamento do navegador; "Limpar dados do site" apaga —
use o backup nas opções do painel dos responsáveis.

## Conteúdo desta pasta
- `index.html` — o jogo (o mesmo motor das builds de extensão)
- `manifest.webmanifest` — identidade do app instalável
- `sw.js` — cache offline
- `icons/` — ícones 192/512 e maskable
- `css/`, `js/` — estilos e motor compartilhados (`js/pwa.js`: convite para instalar)
